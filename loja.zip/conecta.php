<?php
    $conexao = mysqli_connect('localhost:3310', 'root', '', 'loja');