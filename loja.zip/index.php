<?php include("cabecalho.php"); ?>

<?php $nome = "guilherme"; ?>
Loja do <?php echo $nome; ?>

<?php include("rodape.php"); ?>
